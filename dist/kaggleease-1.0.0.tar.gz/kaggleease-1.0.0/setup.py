from setuptools import setup

# This setup.py is kept for backward compatibility.
# New installations should use pyproject.toml
setup()
